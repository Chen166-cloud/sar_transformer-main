# ICSPS 2026 LaTeX draft

Main manuscript: `ICSPS2026_paper.tex`

The directory includes the exact `IEEEtran.cls` distributed in the official
ICSPS 2026 LaTeX package. `official_conference_101719.tex` is retained only as
an unedited template reference; it is not the manuscript entry point.

Compile locally with:

```bash
tectonic ICSPS2026_paper.tex
```

For Overleaf, upload this directory and set `ICSPS2026_paper.tex` as the main
document with the pdfLaTeX compiler. Include the `figures` subdirectory when
uploading. Figure 4 is integrated as `figures/fig4_buildings.pdf`: a 2-by-4
comparison of one buildings scene, with the Ours ratio image in panel (h).
Its caption and the Synthetic Comparison discussion describe this single
scene. Figure 5 is integrated as `figures/fig5_real_sar.pdf`: one real-SAR
scene in the same 2-by-4 layout, with Ours+AMS ratio in panel (h). The original
red annotation in Noisy is retained. Its caption and the Real-SAR Adaptation
discussion describe the single scene and the visible effect of AMS. Figures
1--3 remain boxed placeholders to be replaced before submission.

Figure 4 sources, a reproducible composition script, a PNG preview, and the
source-pixel verification record are in `../../output/pdf/ICSPS2026_Fig4`.
The original 256-by-256 images are embedded losslessly; exporting the composite
preview at 600 dpi does not increase their native information content.

Figure 5 sources, composition script, caption, and previews are in
`../../output/pdf/ICSPS2026_Fig5`. Labels follow the author-confirmed renamed
filenames. The work covers composition and manuscript layout; no local model
identity or historical-output validation is performed for Figure 5.
